import { GoogleGenAI } from "@google/genai";
import { Member, AttendanceRecord } from "../types";

// Initialize Gemini
// Note: API Key should come from process.env.API_KEY
const apiKey = process.env.API_KEY || 'YOUR_API_KEY'; 
const ai = new GoogleGenAI({ apiKey });

export const generateBusinessInsights = async (
  members: Member[],
  attendance: AttendanceRecord[]
): Promise<string> => {
  try {
    // Prepare data summary for the AI (don't send PII like names/phones if real app)
    const activeCount = members.filter(m => m.active).length;
    const totalRevenue = members.reduce((acc, m) => acc + m.amountPaid, 0);
    const recentAttendance = attendance.slice(0, 50).map(a => ({
      type: a.type,
      status: a.status,
      time: a.timestamp
    }));

    const prompt = `
      You are a Gym Business Analyst. Analyze this data:
      - Total Active Members: ${activeCount}
      - Total Revenue: $${totalRevenue}
      - Recent 50 Check-ins: ${JSON.stringify(recentAttendance)}

      Provide 3 short, actionable insights to improve gym efficiency and member retention.
      Keep it professional and motivating. Use bullet points.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Unable to generate insights at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "AI Service Unavailable. Please check API Key.";
  }
};