import { Member } from '../types';

export const sendWhatsAppMessage = async (to: string, message: string, imageUrl?: string): Promise<boolean> => {
  console.log(`[WHATSAPP API MOCK] Sending to ${to}: ${message}`);
  if (imageUrl) console.log(`[WHATSAPP API MOCK] Image attachment: ${imageUrl}`);
  
  // Simulate network delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(true);
    }, 1000);
  });
};

export const sendWelcomeMessage = async (member: Member) => {
  const msg = `Welcome to IronPulse Gym, ${member.name}! Your plan is active. Scan your QR code at the entrance.`;
  await sendWhatsAppMessage(member.phone, msg, member.qrCodeData);
};

export const sendExpiryReminder = async (member: Member) => {
   const msg = `Hi ${member.name}, your IronPulse subscription is expiring soon. Please renew to avoid interruption.`;
   await sendWhatsAppMessage(member.phone, msg);
};