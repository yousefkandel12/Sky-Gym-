import { Member, AttendanceRecord, Staff, PlanType } from '../types';

const STORAGE_KEYS = {
  MEMBERS: 'ironpulse_members',
  ATTENDANCE: 'ironpulse_attendance',
  STAFF: 'ironpulse_staff',
};

// Initialize DB if empty
const initDB = () => {
  if (!localStorage.getItem(STORAGE_KEYS.MEMBERS)) localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify([]));
  if (!localStorage.getItem(STORAGE_KEYS.ATTENDANCE)) localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify([]));
  if (!localStorage.getItem(STORAGE_KEYS.STAFF)) localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify([]));
};

initDB();

// --- Members ---

export const getMembers = (): Member[] => {
  const data = localStorage.getItem(STORAGE_KEYS.MEMBERS);
  return data ? JSON.parse(data) : [];
};

export const addMember = (member: Omit<Member, 'id' | 'active' | 'qrCodeData'>): Member => {
  const members = getMembers();
  const id = crypto.randomUUID();
  const qrCodeData = `MEMBER:${id}`;
  
  const newMember: Member = {
    ...member,
    id,
    active: true,
    qrCodeData,
    remainingSessions: member.planType === PlanType.SESSIONS ? member.totalSessions : undefined
  };

  members.push(newMember);
  localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  return newMember;
};

export const updateMember = (updatedMember: Member) => {
  const members = getMembers();
  const index = members.findIndex(m => m.id === updatedMember.id);
  if (index !== -1) {
    members[index] = updatedMember;
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  }
};

// --- Staff ---

export const getStaff = (): Staff[] => {
  const data = localStorage.getItem(STORAGE_KEYS.STAFF);
  return data ? JSON.parse(data) : [];
};

export const addStaff = (name: string, role: string): Staff => {
  const staffList = getStaff();
  const id = crypto.randomUUID();
  const newStaff: Staff = {
    id,
    name,
    role,
    qrCodeData: `STAFF:${id}`,
    active: true
  };
  staffList.push(newStaff);
  localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify(staffList));
  return newStaff;
};

// --- Attendance ---

export const getAttendance = (): AttendanceRecord[] => {
  const data = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
  return data ? JSON.parse(data) : [];
};

export const logAttendance = (record: Omit<AttendanceRecord, 'id' | 'timestamp'>): AttendanceRecord => {
  const logs = getAttendance();
  const newRecord: AttendanceRecord = {
    ...record,
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
  };
  logs.unshift(newRecord); // Add to top
  localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(logs));
  return newRecord;
};

// --- Logic ---

export const processScan = (qrData: string): { success: boolean; message: string; member?: Member; staff?: Staff } => {
  const [type, id] = qrData.split(':');

  if (type === 'STAFF') {
    const staffList = getStaff();
    const staff = staffList.find(s => s.id === id);
    if (!staff) return { success: false, message: 'Staff not found' };
    
    // Toggle logic for staff could be complex, simplifying to "Check-in" for this demo
    logAttendance({
      memberId: staff.id,
      memberName: staff.name,
      type: 'STAFF',
      status: 'STAFF_IN', 
      note: 'Scanned at Entrance'
    });
    return { success: true, message: `Welcome Staff: ${staff.name}`, staff };
  }

  if (type === 'MEMBER') {
    const members = getMembers();
    const member = members.find(m => m.id === id);

    if (!member) return { success: false, message: 'Member not found' };
    if (!member.active) return { success: false, message: 'Membership inactive' };

    // Check Expiry Date
    if (member.planType === PlanType.TIME_BASED && member.endDate) {
      const today = new Date();
      const end = new Date(member.endDate);
      if (today > end) {
        logAttendance({ memberId: member.id, memberName: member.name, type: 'MEMBER', status: 'DENIED', note: 'Expired' });
        return { success: false, message: 'Membership Expired' };
      }
    }

    // Check Sessions
    if (member.planType === PlanType.SESSIONS) {
      if ((member.remainingSessions || 0) <= 0) {
        logAttendance({ memberId: member.id, memberName: member.name, type: 'MEMBER', status: 'DENIED', note: 'No sessions left' });
        return { success: false, message: 'No Sessions Remaining' };
      }
      // Deduct session
      member.remainingSessions = (member.remainingSessions || 0) - 1;
      updateMember(member);
    }

    logAttendance({ memberId: member.id, memberName: member.name, type: 'MEMBER', status: 'SUCCESS' });
    return { success: true, message: `Welcome ${member.name}!`, member };
  }

  return { success: false, message: 'Invalid QR Code' };
};